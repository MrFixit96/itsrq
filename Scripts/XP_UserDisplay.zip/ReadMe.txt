User Display Settings for Windows XP V2.0
Copyright 2002 by Doug Knox
This program may be freely distributed
Based on VB code by Paul Kuliniewicz at http://www.vbapi.com

NOTICE: This utility was written to run on Windows XP.  It may run on Win 98 through Windows 2000, but it will require the Visual Basic 6 runtime library.

Users who are upgrading to version 2, should run the utility from the Run dialog the first time, using the /R switch.  This is recommended since your desired refresh rate was not stored by the previous version.

1) Installation

There is no installer for this program.  Simply copy the exectutable file to the folder of your choice.  If the program is to be run by all users, then ensure that the folder is accessible by all users.  

Create a shortcut to the UserDisplay.exe file in the Documents and Settings\All Users\Programs\Startup folder.  This will allow all users to have custom settings for their Desktop Resolution and color depth.

2) Usage

The first time each user logs on they will be prompted to set their desired screen size and color depth.  They can, optionally, have their settings remember, and applied at each logon.

Individual user settings are not saved if you switch between users (Fast User Switching).  However, you can create a Hot-key combination for the shortcut, or a Quick Launch bar shortcut, to launch the program.  If you have the Apply this setting...... option selected, it will automatically restore your preferred desktop size, with no other action required on your part.

Settings are saved, on a per-user basis, in the Registry at:

HKEY_CURRENT_USER\Software\Doug's XP Utilities\Resolution

3) Reset User Settings

To allow a user to reset/change their settings, from their desktop, click Start, Run and browse to the folder containing UserDisplay.exe.  Add the -r switch to the end of the command line.  Example: C:\ScreenRes\UserDisplay.exe -r  This will bypass the automatic settings change, and allow the user to change their preferences.

4) Uninstall

There is no Uninstall for this program.  Simply delete the shortcut to the file and the file itself.

5) Options

Currently only 640x480, 800x600, 1024x768, 1152x864, 1280x768, 1280x960 and 1280x1024 are supported for screen sizes. Color depths of 8, 16, 24 and 32 bits are supported.  Your graphics adapter may not support all of these modes.  If you attempt to change to an unsupported mode, you should receive an error message.

6) Warranty, Terms and Conditions

This program is offered as is, with no warranty of any kind. Your use of this program is at your own risk. Your installation and use of this program signifies your agreement to these terms.

7) Support

No support, of any type, is offered for this product.  Feedback may be directed to feedback@dougknox.com